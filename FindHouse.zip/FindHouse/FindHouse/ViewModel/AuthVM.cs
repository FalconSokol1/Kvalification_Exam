﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using FindHouse.Model;
using FindHouse.DbEntity;
using FindHouse.View;

namespace FindHouse.ViewModel
{
    
    public class AuthVM:BaseVM
    {
        private Clients _clients;
        

        private string _email;
        private string _password;
        
        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged(nameof(Password));
            }
        }

        private async Task<bool> Authorize(string email, string password)
        {
            try
            {

                var result = await AppData.DbE.Clients.FirstOrDefaultAsync(client => client.Email == email &&
                        client.Password == password);

                _clients = result;

                if (result != null)
                {
                    return true;
                }

                return false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Необработанное исключение",
                        MessageBoxButton.OK, MessageBoxImage.Stop);

                return false;
            }

        }

        public async void AuthInApp()
        {
            

            if (await Authorize(Email, Password))
            {
                UserSpace userSpace = new UserSpace();

                userSpace.Show();

                AuthClients authClients = new AuthClients();
                authClients.Close();

                foreach (var item in App.Current.Windows)
                {
                    if (item is AuthClients)
                    {
                        (item as Window)?.Close();
                    }
                }
                return;
            }

            TriggersForTBX.TittleTrigger = "Авторизация";
            TriggersForTBX.TextTrigger = "Неверный логин или пароль";

            MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
            messagesBoxCustom.ShowDialog();


        }


    }
}
