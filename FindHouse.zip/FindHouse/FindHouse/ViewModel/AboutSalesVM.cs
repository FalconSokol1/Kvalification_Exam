﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using FindHouse.Model;
using FindHouse.DbEntity;
using System.Collections.ObjectModel;

namespace FindHouse.ViewModel
{
    public class AboutSalesVM : BaseVM
    {


        private Sales _selectedSales;

        private ObservableCollection<Sales> _sales;

        public ObservableCollection<Sales> Sales
        {
            get => _sales;
            set
            {
                _sales = value;
                OnPropertyChanged(nameof(Sales));
            }
        }

        public Sales SelectedSales
        {
            get => _selectedSales;
            set
            {
                _selectedSales = value;
                OnPropertyChanged(nameof(SelectedSales));
            }
        }

        public AboutSalesVM()
        {
            Sales = new ObservableCollection<Sales>();

            LoadData();
        }

        public void LoadData()
        {
            if (Sales.Count > 0)
            {
                Sales.Clear();
            }

            var result = AppData.DbE.Sales.ToList();

            result.ForEach(elem => Sales?.Add(elem));
        }

        public void DeleteSelectItem()
        {
            if (!(SelectedSales is null))
            {
                using (var db = new RealEstateSalesEntities())
                {

                    var result = MessageBox.Show("Вы действительно хотите удалить выбранный элемент?" +
                        "Это действие невозможно отменить.", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        try
                        {
                            var entityForDelete = db.Advertisements.Where(elem => elem.AdvertisementID == SelectedSales.ClientID).FirstOrDefault();

                            db.Advertisements.Remove(entityForDelete);

                            db.SaveChanges();

                            LoadData();

                            MessageBox.Show("Данные успешно удалены", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Информация", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                    }

                }
            }
        }
    }
}
