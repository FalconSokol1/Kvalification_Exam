﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using FindHouse.DbEntity;

namespace FindHouse.ViewModel
{
    public class AboutUsersVM : BaseVM
    {
        private Clients _selectedClients;

        private ObservableCollection<Clients> _clients;

        public ObservableCollection<Clients> Clients
        {
            get => _clients;
            set
            {
                _clients = value;
                OnPropertyChanged(nameof(Clients));
            }
        }

        public Clients SelectedClients
        {
            get => _selectedClients;
            set
            {
                _selectedClients = value;
                OnPropertyChanged(nameof(SelectedClients));
            }
        }

        public AboutUsersVM()
        {
            Clients = new ObservableCollection<Clients>();

            LoadData();
        }

        public void LoadData()
        {
            if (Clients.Count > 0)
            {
                Clients.Clear();
            }

            var result = AppData.DbE.Clients.ToList();

            result.ForEach(elem => Clients?.Add(elem));
        }

        public void DeleteSelectItem()
        {
            if (!(SelectedClients is null))
            {
                using (var db = new RealEstateSalesEntities())
                {

                    var result = MessageBox.Show("Вы действительно хотите удалить выбранный элемент?" +
                        "Это действие невозможно отменить.", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        try
                        {
                            var entityForDelete = db.Clients.Where(elem => elem.ClientID == SelectedClients.ClientID).FirstOrDefault();

                            db.Clients.Remove(entityForDelete);

                            db.SaveChanges();

                            LoadData();

                            MessageBox.Show("Данные успешно удалены", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Информация", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                    }

                }
            }
        }


    }
}
