﻿using FindHouse.DbEntity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FindHouse.ViewModel
{
    public class UserSpaceVM:BaseVM
    {
        private Advertisements _selectedAdvertisement;

        private ObservableCollection<Advertisements> _advertisement;

        public ObservableCollection<Advertisements> Advertisements
        {
            get => _advertisement;
            set
            {
                _advertisement = value;
                OnPropertyChanged(nameof(Advertisements));
            }
        }

        public Advertisements SelectedAdvertisements
        {
            get => _selectedAdvertisement;
            set
            {
                _selectedAdvertisement = value;
                OnPropertyChanged(nameof(SelectedAdvertisements));
            }
        }

        public UserSpaceVM()
        {
            Advertisements = new ObservableCollection<Advertisements>();

            LoadData();
        }

        public void LoadData()
        {
            if (Advertisements.Count > 0)
            {
                Advertisements.Clear();
            }

            var result = AppData.DbE.Advertisements.ToList();

            result.ForEach(elem => Advertisements?.Add(elem));
        }

        public void DeleteSelectItem()
        {
            if (!(SelectedAdvertisements is null))
            {
                using (var db = new RealEstateSalesEntities())
                {

                    var result = MessageBox.Show("Вы действительно хотите удалить выбранный элемент?" +
                        "Это действие невозможно отменить.", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        try
                        {
                            var entityForDelete = db.Advertisements.Where(elem => elem.AdvertisementID == SelectedAdvertisements.AdvertisementID).FirstOrDefault();

                            db.Advertisements.Remove(entityForDelete);

                            db.SaveChanges();

                            LoadData();

                            MessageBox.Show("Данные успешно удалены", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Информация", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                    }

                }
            }
        }


    }
}
