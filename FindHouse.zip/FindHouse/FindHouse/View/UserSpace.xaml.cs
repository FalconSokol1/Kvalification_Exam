﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FindHouse.DbEntity;
using FindHouse.ViewModel;
using FindHouse.View;
using FindHouse.Model;

namespace FindHouse
{
    /// <summary>
    /// Логика взаимодействия для UserSpace.xaml
    /// </summary>
    public partial class UserSpace : Window
    {
        MainWindow mainWindow = new MainWindow();
        

        public UserSpace()
        {
            InitializeComponent();
            
            this.DataContext = new UserSpaceVM();
            
        }

        private void bntExit(object sender, RoutedEventArgs e)
        {
            MainWindow.Outer.Qter = false;
            mainWindow.Show();
            this.Close();
        }

        private void btnTalk(object sender, RoutedEventArgs e)
        {
            
            if (MainWindow.Outer.Qter == false)
            {
                TriggersForTBX.TittleTrigger = "Внимание!";
                TriggersForTBX.TextTrigger = "Недоступно для гостей";

                MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
                messagesBoxCustom.ShowDialog();
            }

            else if (MainWindow.Outer.Qter == true)
            {
                TriggersForTBX.TittleTrigger = "Внимание!";
                TriggersForTBX.TextTrigger = "Временно недоступно";

                MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
                messagesBoxCustom.ShowDialog();
            }
        }

        private void btnChooses(object sender, RoutedEventArgs e)
        {
            if (MainWindow.Outer.Qter == false)
            {
                TriggersForTBX.TittleTrigger = "Внимание!";
                TriggersForTBX.TextTrigger = "Недоступно для гостей";

                MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
                messagesBoxCustom.ShowDialog();
            }
            else if (MainWindow.Outer.Qter == true)
            {
                TriggersForTBX.TittleTrigger = "Внимание!";
                TriggersForTBX.TextTrigger = "Временно недоступно";

                MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
                messagesBoxCustom.ShowDialog();
            }
        }

        private void btnUpdate(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }

        public void RefreshData()
        {
            (DataContext as UserSpaceVM).LoadData();
        }
    }
}
