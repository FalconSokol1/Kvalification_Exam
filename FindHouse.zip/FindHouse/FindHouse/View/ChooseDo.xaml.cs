﻿using FindHouse.Model;
using FindHouse.View;
using FindHouse.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FindHouse
{
    /// <summary>
    /// Логика взаимодействия для ChooseDo.xaml
    /// </summary>
    public partial class ChooseDo : Window
    {
        public ChooseDo()
        {
            InitializeComponent();
        }

        private void btnExit(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnAboutSales(object sender, RoutedEventArgs e)
        {
            AboutSales aboutSales = new AboutSales();
            aboutSales.Show();
            this.Close();
        }

        private void btnAboutUsers(object sender, RoutedEventArgs e)
        {
            AboutUsers aboutUsers = new AboutUsers();
            aboutUsers.Show();
            this.Close();
        }

        private void btnAboutAd(object sender, RoutedEventArgs e)
        {
            AboutAdvertisement AboutAdvertisement = new AboutAdvertisement();
            AboutAdvertisement.Show();
            this.Close();
        }
    }
}
