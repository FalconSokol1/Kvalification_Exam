﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FindHouse.DbEntity;
using FindHouse.Model;
using FindHouse.View;
using FindHouse.ViewModel;

namespace FindHouse.View
{
    /// <summary>
    /// Логика взаимодействия для AddOrEditWindow.xaml
    /// </summary>
    public partial class AddOrEditWindow : Window
    {

        private Advertisements _advertisements;

        public AddOrEditWindow(Advertisements advertisements)
        {
            InitializeComponent();


            foreach (var item in App.Current.Windows)
            {
                if (item is AboutAdvertisement)
                {
                    this.Owner = item as Window;
                }
            }

            if (advertisements is null)
            {
                _advertisements = advertisements = new Advertisements();
            }
            else
            {
                _advertisements = advertisements;
            }


            this.DataContext = advertisements;
        }

        private void btnSaveChange(object sender, RoutedEventArgs e)
        {

            using (var db = new RealEstateSalesEntities())
            {
                try
                {
                    var validateResult = ValidateEntity();

                    if (validateResult.Length > 0)
                    {
                        MessageBox.Show(validateResult.ToString(), "Информация", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    db.Advertisements.AddOrUpdate(_advertisements);

                    db.SaveChanges();

                    TriggersForTBX.TittleTrigger = "Информация!";
                    TriggersForTBX.TextTrigger = "Данные успешно сохранены";

                    MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
                    messagesBoxCustom.ShowDialog();



                    (Owner as UserSpace)?.RefreshData();

                    Owner.Focus();

                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Информация", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }

        }

        private StringBuilder ValidateEntity()
        {
            var errors = new StringBuilder();

            if (_advertisements != null)
            {
                if (string.IsNullOrEmpty(_advertisements.Title))
                {
                    errors.AppendLine("Поле 'Название' не может быть пустым!");
                }

                if(string.IsNullOrEmpty(_advertisements.Description))
                {
                    errors.AppendLine("Пустое описание объявления");
                }

                if (_advertisements.Price <= 0)
                {
                    errors.AppendLine("Некорректная цена!");
                }
                if (_advertisements.SquareFeet <= 0)
                {
                    errors.AppendLine("Введите площадь дома в кв. метрах!");
                }
                if (_advertisements.Bedrooms <= 0)
                {
                    errors.AppendLine("Поле 'Кол-во спален' не может быть пустым!");
                }
                if (_advertisements.Bathrooms <= 0)
                {
                    errors.AppendLine("Поле 'Кол-во ванных' не может быть пустым!");
                }
                if (string.IsNullOrEmpty(_advertisements.Address))
                {
                    errors.AppendLine("Поле 'Адрес' не может быть пустым!");
                }
            }

            return errors;
        }

        private void btnExit(object sender, RoutedEventArgs e)
        {
            AboutAdvertisement advertisement = new AboutAdvertisement();
            advertisement.Show();
            this.Close();
        }
    }


       
    
}
