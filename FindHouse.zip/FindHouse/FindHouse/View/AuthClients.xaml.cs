﻿using FindHouse.DbEntity;
using FindHouse.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FindHouse
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class AuthClients : Window
    {
        
        public AuthClients()
        {
            InitializeComponent();

            this.DataContext = new AuthVM();
        }

        private void btnExit(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void inButton(object sender, RoutedEventArgs e)
        {
            MainWindow.Outer.Qter = true;
            (DataContext as AuthVM).AuthInApp();
            
        }
    }
}
