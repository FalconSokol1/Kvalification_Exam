﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FindHouse
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool QorU = false;

        public static class Outer 
        { 

            public static bool Qter = false;
        }

            public MainWindow()
        {
            InitializeComponent();
        }

        private void onClick(object sender, RoutedEventArgs e)
        {
            AuthClients auth = new AuthClients();
            auth.Show();
            this.Close();
        }

        private void onOpenQ(object sender, RoutedEventArgs e)
        {
            Outer.Qter = false;
            var resQter = Outer.Qter;
            UserSpace userSpace = new UserSpace();
            userSpace.Show();
            this.Close();
        }

        private void btnOpenAdmin(object sender, RoutedEventArgs e)
        {
            AuthAdmins authAdmins = new AuthAdmins();
            authAdmins.Show();
            this.Close();
        }

        private void onClose(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
