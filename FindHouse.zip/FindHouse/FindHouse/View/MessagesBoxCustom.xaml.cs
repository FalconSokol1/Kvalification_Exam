﻿using FindHouse.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FindHouse.View
{
    /// <summary>
    /// Логика взаимодействия для MessagesBoxCustom.xaml
    /// </summary>
    public partial class MessagesBoxCustom : Window
    {
        public MessagesBoxCustom()
        {
            InitializeComponent();

            UserSpace userSpace = new UserSpace();
            TittleTrigger.Text = TriggersForTBX.TittleTrigger;
            TextTrigger.Text = TriggersForTBX.TextTrigger;

        }

        private void btnOk(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
