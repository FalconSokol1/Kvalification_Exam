﻿using FindHouse.Model;
using FindHouse.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FindHouse.ViewModel
{
    /// <summary>
    /// Логика взаимодействия для AboutAdvertisement.xaml
    /// </summary>
    public partial class AboutAdvertisement : Window
    {
        public AboutAdvertisement()
        {
            InitializeComponent();
            this.DataContext = new UserSpaceVM();
        }

        private void bntExit(object sender, RoutedEventArgs e)
        {
            ChooseDo chooseDo = new ChooseDo();
            chooseDo.Show();
            this.Close();
        }

        private void btnLoadData(object sender, RoutedEventArgs e)
        {
            (DataContext as UserSpaceVM).LoadData();
        }

        private void btnDelete(object sender, RoutedEventArgs e)
        {
            (DataContext as UserSpaceVM).DeleteSelectItem();
        }

        private void btnEdit(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddOrEditWindow((DataContext as UserSpaceVM).SelectedAdvertisements);

            addWindow.ShowDialog();

        }

        private void btnAddNew(object sender, RoutedEventArgs e)
        {
            TriggersForTBX.TittleTrigger = "Внимание!";
            TriggersForTBX.TextTrigger = "Временно недоступно";

            MessagesBoxCustom messagesBoxCustom = new MessagesBoxCustom();
            messagesBoxCustom.ShowDialog();
        }
    }
}
