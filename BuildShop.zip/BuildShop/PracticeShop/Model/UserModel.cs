﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildShop.Model
{
    public class UserModel
    {
        public int UserID { get; set; }
        public string UserLogin { get; set; }
        public string Email { get; set; }
        public string UserPassword { get; set; }

    }
}
