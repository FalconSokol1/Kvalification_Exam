﻿using BuildShop.DbEnti;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.Windows;
using System.Data.Entity;
using BuildShop.Model;

namespace BuildShop.ViewModel
{
    public class MainWindowVM : BaseVM

    {

        private ObservableCollection<Products> _products;
        
        
        private Products _selecteProducts;

        public ObservableCollection<Products> Products
        {
            get => _products;
            set
            {
                _products = value;
                OnPropertyChanged(nameof(Products));

            }
        }

      

        public Products SelectedProducts
        {
            get => _selecteProducts;
            set
            {
                _selecteProducts = value;
                OnPropertyChanged(nameof(SelectedProducts));
            }
        }

        public MainWindowVM()
        {
            RebindData();
            SetTimer();

        }

        public void dispatcherTimer_Tick(object sender, EventArgs e)
        {

            RebindData();
        }




        public void RebindData()
        {

            Products = new ObservableCollection<Products>();
            LoadData();
        }




        private void SetTimer()
        {
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 5);
            dispatcherTimer.Start();
        }

        public void DeleteSelectItem()
        {
            if (!(SelectedProducts is null))
            {
                using (var db = new StoreEntities())
                {

                    var result = MessageBox.Show("Вы действительно хотите удалить выбранный товар?" +
                        "Это действие невозможно отменить.", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        try
                        {
                            var entityForDelete = db.Products.Where(elem => elem.ProductID == SelectedProducts.ProductID).FirstOrDefault();

                            db.Products.Remove(entityForDelete);

                            db.SaveChanges();

                            LoadData();

                            MessageBox.Show("Рейс успешно удален", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Информация", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                    }

                }
            }
        }

       


        public void LoadData()
        {


            if (Products.Count > 0)
            {
                Products.Clear();
            }

            var result = AppData.db.Products.ToList();

            result.ForEach(elem => Products?.Add(elem));
        }


    }

}
